CREATE TRIGGER UpdateMasterActivity
    ON AFZ_Activity
    AFTER UPDATE, INSERT
AS
BEGIN
    IF EXISTS (SELECT Master_Activity_ID FROM inserted)
    BEGIN
        UPDATE A
        SET A.Amount_Due =
            (SELECT SUM(COALESCE(B.Amount_Due, 0))
             FROM AFZ_Activity B
             WHERE B.Master_Activity_ID = I.Master_Activity_ID
                OR B.Activity_ID = I.Master_Activity_ID)
        FROM AFZ_Activity A
        INNER JOIN inserted I ON A.Activity_ID = I.Master_Activity_ID;

    END
END
go

