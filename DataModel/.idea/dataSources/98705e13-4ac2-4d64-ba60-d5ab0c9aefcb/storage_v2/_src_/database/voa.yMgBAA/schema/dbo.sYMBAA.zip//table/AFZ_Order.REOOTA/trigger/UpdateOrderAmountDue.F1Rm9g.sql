CREATE TRIGGER UpdateOrderAmountDue
     ON AFZ_Order
     AFTER INSERT
     AS
     BEGIN
        DECLARE @newAmount TABLE (Activity_ID NUMERIC(5), Amount NUMERIC(10, 2))

        INSERT INTO @newAmount
        SELECT O.Activity_ID, sum(O.Quantity * AIS.Unit_Price)
        FROM AFZ_Order O
        JOIN AFZ_Item_Store AIS on AIS.Item_ID = O.Item_ID AND AIS.Facility_ID = o.Store_Facility_ID
        INNER JOIN inserted i ON O.Activity_ID = i.Activity_ID
        GROUP BY O.Activity_ID


        UPDATE AFZ_Activity
        SET AFZ_Activity.Amount_Due = NA.Amount
        FROM @newAmount NA
        JOIN AFZ_Activity ON NA.Activity_ID = AFZ_Activity.Activity_ID
     END
go

