CREATE PROCEDURE get_expenditure_summary_data_by_user_id (@input_id NUMERIC(10)) AS
BEGIN
    SELECT concat(AV.Fname, ' ', av.Lname) 'Visitor_Name',
           APA.Payment_Date,
           ISNULL(AF.Facility_Name ,'N/A') 'Facility_Name',
           AST.Source_Type_Name,
           APA.Payment_Amount
    FROM AFZ_Visitors AV
    JOIN AFZ_Visitor_Type AVT on AV.Visitor_Type_ID = AVT.Visitor_Type_ID
    JOIN AFZ_Activity AA on AV.Visitor_ID = AA.Visitor_ID
    join AFZ_Payment APA on AA.Activity_ID = APA.Activity_ID
    LEFT JOIN AFZ_Facility AF on AA.Facility_ID = AF.Facility_ID
    LEFT JOIN AFZ_Parking AP on AA.Activity_ID = AP.Activity_ID
    LEFT JOIN AFZ_Source_Type AST on AA.Source_Type = AST.Source_Type
    WHERE AV.Visitor_ID = @input_id
    order by Payment_Date;
END
go

