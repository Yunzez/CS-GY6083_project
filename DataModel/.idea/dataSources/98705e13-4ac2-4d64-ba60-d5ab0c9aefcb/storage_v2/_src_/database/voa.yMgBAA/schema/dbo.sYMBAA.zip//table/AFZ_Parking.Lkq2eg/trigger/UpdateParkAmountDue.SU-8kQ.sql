CREATE TRIGGER UpdateParkAmountDue
     ON AFZ_Parking
     AFTER INSERT, UPDATE
     AS
     BEGIN
        DECLARE @newAmount TABLE (Activity_ID NUMERIC(5), Amount NUMERIC(10, 2))

        INSERT INTO @newAmount
        SELECT P.Activity_ID, SUM(P.Fee * DATEDIFF(SECOND, i.Time_In, i.Time_Out) / 3600.0)
        FROM AFZ_Parking P
        INNER JOIN inserted i ON P.Activity_ID = i.Activity_ID
        GROUP BY P.Activity_ID

        UPDATE AFZ_Activity
        SET AFZ_Activity.Amount_Due = NA.Amount
        FROM @newAmount NA
        JOIN AFZ_Activity ON NA.Activity_ID = AFZ_Activity.Activity_ID
     END
go

