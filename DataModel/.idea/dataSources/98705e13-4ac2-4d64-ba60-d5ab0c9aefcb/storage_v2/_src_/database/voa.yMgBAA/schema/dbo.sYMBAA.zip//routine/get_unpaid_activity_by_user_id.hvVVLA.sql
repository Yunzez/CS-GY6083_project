CREATE PROCEDURE get_unpaid_activity_by_user_id (@input_id NUMERIC(10)) AS
BEGIN
    SELECT AA.Activity_ID, AA.Amount_Due, AA.Activity_Date, AST.Source_Type_Name, AA.Facility_ID, AF.Facility_Name
    FROM AFZ_Activity AA WITH (UPDLOCK)
    LEFT JOIN AFZ_Payment AP on AA.Activity_ID = AP.Activity_ID
    LEFT JOIN AFZ_Source_Type AST on AA.Source_Type = AST.Source_Type
    left join AFZ_Facility AF on AA.Facility_ID = AF.Facility_ID
    WHERE Amount_Due IS NOT NULL AND Payment_Amount IS NULL and AA.Visitor_ID = @input_id
END
go

