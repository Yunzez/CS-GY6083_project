CREATE TRIGGER UpdateGuestVisitor
    ON AFZ_Visitors
    INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT inserted.Visitor_ID
        FROM inserted
        JOIN AFZ_Visitors on AFZ_Visitors.Email = inserted.Email
        WHERE inserted.Visitor_Type_ID != 6
    )
    BEGIN
        UPDATE AFZ_Visitors
        SET AFZ_Visitors.Birthdate = inserted.Birthdate,
            AFZ_Visitors.Fname = inserted.Fname,
            AFZ_Visitors.Lname = inserted.Lname,
            AFZ_Visitors.Password = inserted.Password,
            AFZ_Visitors.Cell_Number = inserted.Cell_Number,
            AFZ_Visitors.City = inserted.City
            FROM inserted
            WHERE AFZ_Visitors.Email = inserted.Email
    END
END
go

